import csv
import openpyxl
import os
import shutil
import requests
import tempfile
import tkinter as tk
from tkinter import *
monthA = ['']*13
monthNum = ['']*13
monthTemplate = ['']*13
year = 0
def monthData():
  global monthA
  global monthNum
  global monthTemplate
  monthA[1] = '01 Jänner.xlsx'
  monthA[2] = '02 Februar.xlsx'
  monthA[3] = '03 März.xlsx'
  monthA[4] = '04 April.xlsx'
  monthA[5] = '05 Mai.xlsx'
  monthA[6] = '06 Juni.xlsx'
  monthA[7] = '07 Juli.xlsx'
  monthA[8] = '08 August.xlsx'
  monthA[9] = '09 September.xlsx'
  monthA[10] ='10 Oktober.xlsx'
  monthA[11] ='11 November.xlsx'
  monthA[12] ='12 Dezember.xlsx'
  monthNum [1] = '01'
  monthNum [2] = '02'
  monthNum [3] = '03'
  monthNum [4] = '04'
  monthNum [5] = '05'
  monthNum [6] = '06'
  monthNum [7] = '07'
  monthNum [8] = '08'
  monthNum [9] = '09'
  monthNum [10] = '10'
  monthNum [11] = '11'
  monthNum [12] = '12'
  monthTemplate[1] = 'Vorlage_31.xlsx'
  monthTemplate[3] = 'Vorlage_31.xlsx'
  monthTemplate[4] = 'Vorlage_30.xlsx'
  monthTemplate[5] = 'Vorlage_31.xlsx'
  monthTemplate[6] = 'Vorlage_30.xlsx'
  monthTemplate[7] = 'Vorlage_31.xlsx'
  monthTemplate[8] = 'Vorlage_31.xlsx'
  monthTemplate[9] = 'Vorlage_30.xlsx'
  monthTemplate[10] = 'Vorlage_31.xlsx'
  monthTemplate[11] = 'Vorlage_30.xlsx'
  monthTemplate[12] = 'Vorlage_31.xlsx'
def leapYear():
  global monthTemplate
  global year
  if (int(year)) % 4 == 0: monthTemplate[2] = 'Vorlage_29.xlsx'
  else: monthTemplate[2] = 'Vorlage_28.xlsx'
monthData()
month = 1
csv_path = ''
file_labels = []
def main(month) :
  global monthA
  global monthNum
  global monthTemplate
  global year
  global csv_path
  global txt
  counter = 0
  fileName = 'EXP' + monthNum[month] + '_' + (str((int(year))-2000)) + '.CSV'
  if os.path.exists(fileName):
    print('Getting template')
    if os.path.exists('C:\\Users\\manue\\AppData\\Local\\Temp\\' + monthTemplate[month]) :
      shutil.copy('C:\\Users\\manue\\AppData\\Local\\Temp\\' + monthTemplate[month], monthA[month])
      print('Opening file', fileName)
    else :
      url = 'https://github.com/Leitna/wswin/blob/main/' + monthTemplate[month] + '?raw=true'
      response = requests.get(url)
      if response.status_code == 200:
        file_path = os.path.join(tempfile.gettempdir(), monthTemplate[month])
        with open(file_path, 'wb') as f:
          f.write(response.content)
          shutil.copy(file_path, monthA[month])
      else:
        print('Failed to download file')
    with open(fileName, mode='r') as csv_file:
      csv_reader = csv.reader(csv_file)
      print('Processing')
      workbook = openpyxl.load_workbook(monthA[month])
      temp = workbook.create_sheet('temp')
      for i in range(4):
        next(csv_reader)
      for row in csv_reader:
        if len(row) >= 39:
          col1 = row[3]
          col2 = row[31]
          col3 = row[38]
          col4 = row[36]
          temp.append([col1, col2, col3, col4])
      modified_values = []
      for row in temp.iter_rows():
        modified_row = []
        for cell in row:
          if isinstance(cell.value, str) and "." in cell.value:
            modified_row.append(cell.value.replace(".", ","))
          else:
            modified_row.append(cell.value)
        modified_values.append(modified_row)
        counter += 1
        print(f'Processed row {counter}')
    print('File ' + fileName + ' processed')
    print('Writing to ' + monthA[month])
    exp = workbook['EXP']
    for row in modified_values:
      print(row)
      exp.append(row)
    workbook.remove(temp)
    workbook.save(monthA[month])
    print('File ' + monthA[month] + ' saved\nTrying next file\n')
  else:
    print('Error: Input file ' + fileName + ' not found\nTrying next file\n')
def start_all():
  global year
  year = yearInput.get()
  leapYear()
  startCounter = 1
  while startCounter <= 12:
    main(startCounter)
    startCounter += 1
  exit()
root = tk.Tk()
root.title('WSWIN')
textYear = Label(root, text='Jahr eingeben')
textYear.grid(row=0, column=0)
yearInput = Entry()
yearInput.grid(row=1, column=0)
buttonStartAll = tk.Button(root, text='Start', command=start_all)
buttonStartAll.grid(row=0, column=1)
root.mainloop()